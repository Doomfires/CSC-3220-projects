﻿namespace HW7_ErkinGeorge
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.regFormNameLabel = new System.Windows.Forms.Label();
            this.regFormCompLabel = new System.Windows.Forms.Label();
            this.regFormCityLabel = new System.Windows.Forms.Label();
            this.regFormEmailLabel = new System.Windows.Forms.Label();
            this.regFormNameTtxbox = new System.Windows.Forms.TextBox();
            this.regFormCityTxtbox = new System.Windows.Forms.TextBox();
            this.regFormCompTxtbox = new System.Windows.Forms.TextBox();
            this.regFormEmailTxtbox = new System.Windows.Forms.TextBox();
            this.stateListComboBox = new System.Windows.Forms.ComboBox();
            this.registrationGroupBox = new System.Windows.Forms.GroupBox();
            this.createRegistrationButton = new System.Windows.Forms.Button();
            this.registrationGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // regFormNameLabel
            // 
            this.regFormNameLabel.AutoSize = true;
            this.regFormNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regFormNameLabel.Location = new System.Drawing.Point(12, 18);
            this.regFormNameLabel.Name = "regFormNameLabel";
            this.regFormNameLabel.Size = new System.Drawing.Size(51, 20);
            this.regFormNameLabel.TabIndex = 0;
            this.regFormNameLabel.Text = "Name";
            // 
            // regFormCompLabel
            // 
            this.regFormCompLabel.AutoSize = true;
            this.regFormCompLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regFormCompLabel.Location = new System.Drawing.Point(12, 76);
            this.regFormCompLabel.Name = "regFormCompLabel";
            this.regFormCompLabel.Size = new System.Drawing.Size(76, 20);
            this.regFormCompLabel.TabIndex = 1;
            this.regFormCompLabel.Text = "Company";
            // 
            // regFormCityLabel
            // 
            this.regFormCityLabel.AutoSize = true;
            this.regFormCityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regFormCityLabel.Location = new System.Drawing.Point(12, 123);
            this.regFormCityLabel.Name = "regFormCityLabel";
            this.regFormCityLabel.Size = new System.Drawing.Size(35, 20);
            this.regFormCityLabel.TabIndex = 2;
            this.regFormCityLabel.Text = "City";
            // 
            // regFormEmailLabel
            // 
            this.regFormEmailLabel.AutoSize = true;
            this.regFormEmailLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regFormEmailLabel.Location = new System.Drawing.Point(12, 174);
            this.regFormEmailLabel.Name = "regFormEmailLabel";
            this.regFormEmailLabel.Size = new System.Drawing.Size(48, 20);
            this.regFormEmailLabel.TabIndex = 3;
            this.regFormEmailLabel.Text = "Email";
            // 
            // regFormNameTtxbox
            // 
            this.regFormNameTtxbox.Location = new System.Drawing.Point(180, 20);
            this.regFormNameTtxbox.Name = "regFormNameTtxbox";
            this.regFormNameTtxbox.Size = new System.Drawing.Size(100, 20);
            this.regFormNameTtxbox.TabIndex = 0;
            // 
            // regFormCityTxtbox
            // 
            this.regFormCityTxtbox.Location = new System.Drawing.Point(180, 125);
            this.regFormCityTxtbox.Name = "regFormCityTxtbox";
            this.regFormCityTxtbox.Size = new System.Drawing.Size(100, 20);
            this.regFormCityTxtbox.TabIndex = 2;
            // 
            // regFormCompTxtbox
            // 
            this.regFormCompTxtbox.Location = new System.Drawing.Point(180, 78);
            this.regFormCompTxtbox.Name = "regFormCompTxtbox";
            this.regFormCompTxtbox.Size = new System.Drawing.Size(100, 20);
            this.regFormCompTxtbox.TabIndex = 1;
            // 
            // regFormEmailTxtbox
            // 
            this.regFormEmailTxtbox.Location = new System.Drawing.Point(180, 176);
            this.regFormEmailTxtbox.Name = "regFormEmailTxtbox";
            this.regFormEmailTxtbox.Size = new System.Drawing.Size(100, 20);
            this.regFormEmailTxtbox.TabIndex = 3;
            // 
            // stateListComboBox
            // 
            this.stateListComboBox.FormattingEnabled = true;
            this.stateListComboBox.Location = new System.Drawing.Point(381, 20);
            this.stateListComboBox.Name = "stateListComboBox";
            this.stateListComboBox.Size = new System.Drawing.Size(121, 21);
            this.stateListComboBox.TabIndex = 4;
            // 
            // registrationGroupBox
            // 
            this.registrationGroupBox.Controls.Add(this.createRegistrationButton);
            this.registrationGroupBox.Controls.Add(this.stateListComboBox);
            this.registrationGroupBox.Controls.Add(this.regFormEmailTxtbox);
            this.registrationGroupBox.Controls.Add(this.regFormCompTxtbox);
            this.registrationGroupBox.Controls.Add(this.regFormCityTxtbox);
            this.registrationGroupBox.Controls.Add(this.regFormNameTtxbox);
            this.registrationGroupBox.Controls.Add(this.regFormEmailLabel);
            this.registrationGroupBox.Controls.Add(this.regFormCityLabel);
            this.registrationGroupBox.Controls.Add(this.regFormCompLabel);
            this.registrationGroupBox.Controls.Add(this.regFormNameLabel);
            this.registrationGroupBox.Location = new System.Drawing.Point(21, 36);
            this.registrationGroupBox.Name = "registrationGroupBox";
            this.registrationGroupBox.Size = new System.Drawing.Size(593, 260);
            this.registrationGroupBox.TabIndex = 5;
            this.registrationGroupBox.TabStop = false;
            this.registrationGroupBox.Text = "groupBox1";
            // 
            // createRegistrationButton
            // 
            this.createRegistrationButton.Location = new System.Drawing.Point(469, 231);
            this.createRegistrationButton.Name = "createRegistrationButton";
            this.createRegistrationButton.Size = new System.Drawing.Size(118, 23);
            this.createRegistrationButton.TabIndex = 5;
            this.createRegistrationButton.Text = "Create Registration";
            this.createRegistrationButton.UseVisualStyleBackColor = true;
            this.createRegistrationButton.Click += new System.EventHandler(this.createRegistrationButton_Click);
            // 
            // RegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(655, 355);
            this.Controls.Add(this.registrationGroupBox);
            this.Name = "RegistrationForm";
            this.Text = "RegistrationForm";
            this.registrationGroupBox.ResumeLayout(false);
            this.registrationGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label regFormNameLabel;
        private System.Windows.Forms.Label regFormCompLabel;
        private System.Windows.Forms.Label regFormCityLabel;
        private System.Windows.Forms.Label regFormEmailLabel;
        private System.Windows.Forms.TextBox regFormNameTtxbox;
        private System.Windows.Forms.TextBox regFormCityTxtbox;
        private System.Windows.Forms.TextBox regFormCompTxtbox;
        private System.Windows.Forms.TextBox regFormEmailTxtbox;
        private System.Windows.Forms.ComboBox stateListComboBox;
        private System.Windows.Forms.GroupBox registrationGroupBox;
        private System.Windows.Forms.Button createRegistrationButton;
    }
}