﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW7_ErkinGeorge
{
    class Registrant
    {
        private string _Name;
        private string _Company;
        private string _City;
        private string _State;
        private int _Zip;
        private string _Phone;
        private string _Email;

        //default constructor 
        public Registrant()
        {
            _Name = "";
            _Company = "";
            _City = "";
            _State = "";
            _Zip = 0;
            _Phone = "";
            _Email = "";
        }

        public Registrant(string name)
        {

        }

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }  
        }

        public string Company
        {
            get { return _Company; }
            set { _Company = value; }
        }

        public string Phone

        {
            get { return _Phone; }
            set { _Phone = value; }
        }

        public string Email
        {
            get { return _Email; }
            set { _Email = value; }
        }

        public string cityState
        {
            get { return _City; }

        }

        
    }
}
