﻿namespace HW7_ErkinGeorge
{
    partial class ReceiptForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.receiptFormSubmitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // receiptFormSubmitButton
            // 
            this.receiptFormSubmitButton.Location = new System.Drawing.Point(235, 283);
            this.receiptFormSubmitButton.Name = "receiptFormSubmitButton";
            this.receiptFormSubmitButton.Size = new System.Drawing.Size(75, 23);
            this.receiptFormSubmitButton.TabIndex = 0;
            this.receiptFormSubmitButton.Text = "Submit";
            this.receiptFormSubmitButton.UseVisualStyleBackColor = true;
            // 
            // ReceiptForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 346);
            this.Controls.Add(this.receiptFormSubmitButton);
            this.Name = "ReceiptForm";
            this.Text = "ReceiptForm";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button receiptFormSubmitButton;
    }
}